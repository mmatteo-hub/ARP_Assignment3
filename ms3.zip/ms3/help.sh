# print the .txt file
cd -- "$(find . -iname src -type d)"

less source/drone_ms3.txt